package br.com.bytebank.banco.modelo;

public interface Tributavel {
	
	//public abstract double getValorImposto();
	double getValorImposto(); // eh a mesma coisa de acima

}
