package br.com.alura.java.io.teste;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.net.Socket;

public class TesteCopiarArquivo {

	public static void main(String[] args) throws IOException {
		
		// comunicação via rede
		Socket s = new Socket(); // falta o outro lado
			
		//InputStream fis = new FileInputStream("lorem.txt"); // Entrada com arquivo
		//InputStream fis = System.in; // Entrada pelo teclado -> "enter" para finalizar	
		InputStream fis = s.getInputStream(); // rede
		Reader isr = new InputStreamReader(fis);
		BufferedReader br = new BufferedReader(isr);
		
		// Saída
		//OutputStream fos = new FileOutputStream("lorem2.txt"); // Saída com arquivo
		//OutputStream fos = System.out; // Saída no console
		OutputStream fos = s.getOutputStream(); // rede
		Writer osw = new OutputStreamWriter(fos);
		BufferedWriter bw = new BufferedWriter(osw);
		
		String linha = br.readLine(); 
				
		// copia arquivo inteiro ou input via teclado 
		while(linha != null && !linha.isEmpty()) {
			bw.write(linha);
			bw.newLine();
			bw.flush(); // imprime linha a linha
			linha = br.readLine();
		}
					
		br.close();
		bw.close();
	}

}
