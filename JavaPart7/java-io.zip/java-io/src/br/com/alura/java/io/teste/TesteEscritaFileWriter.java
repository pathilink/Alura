package br.com.alura.java.io.teste;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;

public class TesteEscritaFileWriter {

	public static void main(String[] args) throws IOException {
		
		// Fluxo de Saída com Arquivo - decorator		
//		OutputStream fos = new FileOutputStream("lorem2.txt");			
//		Writer osw = new OutputStreamWriter(fos);
//		BufferedWriter bw = new BufferedWriter(osw);
		
		long ini = System.currentTimeMillis();
		
		//FileWriter fw = new FileWriter("lorem2.txt"); 
		BufferedWriter bw = new BufferedWriter(new FileWriter("lorem2.txt"));
		bw.write("Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod ");
		//fw.write("\n"); // linha em branco
		//fw.write(System.lineSeparator()); // forma independente de sistema operacional
		bw.newLine();
		bw.write("djwiworkfkdldl fkfkf glgllg");
		
		bw.close();
		
		long fim = System.currentTimeMillis();

        System.out.println("Passaram " + (fim - ini) + " milissegundos.");
	}

}
